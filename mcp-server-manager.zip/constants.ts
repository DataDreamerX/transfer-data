import { TransportType } from './types';

export const TRANSPORT_TYPES: TransportType[] = Object.values(TransportType);
