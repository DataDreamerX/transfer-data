import type React from "react"
import type { Metadata } from "next"
import "./globals.css"

export const metadata: Metadata = {
  title: "Voice Chat Bot - Humana Nucleus",
  description: "A voice-enabled chat bot interface built with Humana Nucleus CSS",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link href="https://cdn.jsdelivr.net/npm/@humana/nucleus@latest/dist/css/nucleus.min.css" rel="stylesheet" />
      </head>
      <body>{children}</body>
    </html>
  )
}
